@extends('layout/navbar')

@section('title', " - TMDB")

@section('header')
    
@endsection

@section('main')
    {{dd($Movie)}}
@endsection