

<?php $__env->startSection('title', "Upcoming - TMDB"); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="content">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $upcomingMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mt-5" style="width:13rem;margin-right:15px;margin-left:15px;background-color:#F5F5F5">
                    <a href="/detail/<?php echo e($movie['id']); ?>"><img src="https://www.themoviedb.org/t/p/w440_and_h660_face/<?php echo e($movie['poster_path']); ?>" class="card-img-top mt-2"></a>
                    <div class="card-body">
                        <p class="movie_score"><?php echo e($movie['vote_average']); ?></p>
                        <a href="/detail/<?php echo e($movie['id']); ?>"><h5 class="card-title"><?php echo e($movie['title']); ?></h5></a>
                        <p class="card-text"><?php echo e($movie['release_date']); ?></p>
                    </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\themoviedb\resources\views/upcoming.blade.php ENDPATH**/ ?>