

<?php $__env->startSection('title', " - TMDB"); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <?php echo e(dd($Movie)); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\themoviedb\resources\views/detail.blade.php ENDPATH**/ ?>